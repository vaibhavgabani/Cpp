using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
//using System.Drawing; // Add this for Color

namespace Assignment_1
{
    public partial class P04 : Form
    {
        private string infixString;
        public P04()
        {
            InitializeComponent();
            pictureBox.SendToBack();
        }

        private static int Priority(char ch) // Function to determine the precedence of operators
        {
            return ch == '+' || ch == '-' ? 1 : ch == '*' || ch == '/' ? 2 : ch == '^' ? 3 : 0;
        }

        private static bool IsOperator(char ch) // Function to check if a character is an operator
        {
            return ch == '+' || ch == '-' || ch == '*' || ch == '/' || ch == '%';
        }

        private static string InfixToPostfix(string infix) // Function to convert infix expression to postfix expression
        {
            Stack<char> stack = new Stack<char>();
            StringBuilder postfix = new StringBuilder();

            for (int i = 0; i < infix.Length; i++)
            {
                char ch = infix[i];

                if (char.IsDigit(ch) || ch == '.')
                {
                    postfix.Append(ch);
                }
                else if (ch == '(')
                {
                    stack.Push(ch);
                }
                else if (ch == ')')
                {
                    while (stack.Count > 0 && stack.Peek() != '(')
                    {
                        postfix.Append(' ');
                        postfix.Append(stack.Pop());
                    }
                    if (stack.Count == 0 || stack.Peek() != '(')
                    {
                        throw new InvalidOperationException("Invalid Expression");
                    }
                    else
                    {
                        stack.Pop();
                    }
                }
                else
                {
                    postfix.Append(' ');
                    while (stack.Count > 0 && Priority(stack.Peek()) >= Priority(ch))
                    {
                        postfix.Append(stack.Pop());
                        postfix.Append(' ');
                    }
                    stack.Push(ch);
                }
            }

            while (stack.Count > 0)
            {
                if (stack.Peek() == '(')
                {
                    throw new InvalidOperationException("Invalid Expression");
                }
                postfix.Append(' ');
                postfix.Append(stack.Pop());
            }

            return postfix.ToString();
        }

        private static double EvaluatePostfix(string postfix) // Function to evaluate a postfix expression
        {
            Stack<double> stack = new Stack<double>();
            string[] tokens = postfix.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string token in tokens)
            {
                if (double.TryParse(token, out double num))
                {
                    stack.Push(num);
                }
                else if (IsOperator(token[0]))
                {
                    if (stack.Count < 2)
                    {
                        throw new InvalidOperationException("Invalid postfix expression.");
                    }

                    double num2 = stack.Pop();
                    double num1 = stack.Pop();
                    double ans = 0;

                    switch (token[0])
                    {
                        case '+':
                            ans = num1 + num2;
                            break;
                        case '-':
                            ans = num1 - num2;
                            break;
                        case '*':
                            ans = num1 * num2;
                            break;
                        case '/':
                            ans = num1 / num2;
                            break;
                        case '%':
                            ans = num1 % num2;
                            break;
                    }

                    stack.Push(ans);
                }
                else
                {
                    throw new InvalidOperationException("Invalid character in postfix expression.");
                }
            }

            if (stack.Count == 1)
            {
                return stack.Pop();
            }
            else
            {
                throw new InvalidOperationException("Invalid postfix expression.");
            }
        }

        private void Form1_Load(object sender, EventArgs e) // Form load event handler
        {

        }

        private void inputBtns(object sender, EventArgs e) // Function to handle input button clicks
        {
            textBoxInfix.ForeColor = Color.FromArgb(0, 0, 0);
            textBoxAns.ForeColor = Color.FromArgb(75, 68, 83);
            textBoxInfix.Font = new Font("Segoe UI Black", 29F, FontStyle.Bold);
            textBoxInfix.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold);
            Button inputButtons = sender as Button;
            infixString = inputButtons.Text;
            if ((textBoxInfix.Text.Length == 0) && (infixString == "+" || infixString == "-" || infixString == "*" || infixString == "/"))
            {
                textBoxInfix.Text = "Invalid Format Used";
            }
            else
            {
                textBoxInfix.Text += infixString;
            }
        }

        private void equalBtn(object sender, EventArgs e) // Function to handle the equal button click
        {
            try
            {
                string postfix = InfixToPostfix(textBoxInfix.Text);
                double result = EvaluatePostfix(postfix);
                textBoxAns.Text = result.ToString();
                textBoxInfix.ForeColor = Color.FromArgb(75, 68, 83);
                textBoxAns.ForeColor = Color.FromArgb(0, 0, 0);
                textBoxAns.Font = new Font("Segoe UI Black", 29F, FontStyle.Bold);
                textBoxInfix.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold);
            }
            catch
            {
                textBoxAns.Text = "ERROR";
            }
        }

        private void clearBtn(object sender, EventArgs e) // Function to handle the clear button click
        {
            textBoxInfix.ForeColor = Color.FromArgb(0, 0, 0);
            textBoxInfix.Font = new Font("Segoe UI Black", 29F, FontStyle.Bold);
            textBoxInfix.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold);
            textBoxInfix.Text = string.Empty;
            textBoxAns.Text = string.Empty;
            infixString = "";
        }
    }
}


// code 2

using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing; // Add this for Color

namespace Assignment_1
{
    public partial class P04 : Form
    {
        private string infixString;
        public P04()
        {
            InitializeComponent();
            pictureBox.SendToBack();
        }

        private static int Priority(char ch) // Function to determine the precedence of operators
        {
            return ch == '+' || ch == '-' ? 1 : ch == '*' || ch == '/' ? 2 : 0;
        }

        private static bool IsOperator(char ch) // Function to check if a character is an operator
        {
            return ch == '+' || ch == '-' || ch == '*' || ch == '/';
        }

        private static string InfixToPostfix(string infix) // Function to convert infix expression to postfix expression
        {
            Stack<char> stack = new Stack<char>();
            StringBuilder postfix = new StringBuilder();

            for (int i = 0; i < infix.Length; i++)
            {
                char ch = infix[i];

                if (char.IsDigit(ch) || ch == '.')
                {
                    postfix.Append(ch);
                }
                else if (IsOperator(ch))
                {
                    postfix.Append(' ');
                    while (stack.Count > 0 && Priority(stack.Peek()) >= Priority(ch))
                    {
                        postfix.Append(stack.Pop());
                        postfix.Append(' ');
                    }
                    stack.Push(ch);
                }
            }

            while (stack.Count > 0)
            {
                postfix.Append(' ');
                postfix.Append(stack.Pop());
            }

            return postfix.ToString();
        }

        private static double EvaluatePostfix(string postfix) // Function to evaluate a postfix expression
        {
            Stack<double> stack = new Stack<double>();
            string[] tokens = postfix.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string token in tokens)
            {
                if (double.TryParse(token, out double num))
                {
                    stack.Push(num);
                }
                else if (IsOperator(token[0]))
                {
                    if (stack.Count < 2)
                    {
                        return double.NaN; // Return NaN to indicate an error
                    }

                    double num2 = stack.Pop();
                    double num1 = stack.Pop();
                    double ans = 0;

                    switch (token[0])
                    {
                        case '+':
                            ans = num1 + num2;
                            break;
                        case '-':
                            ans = num1 - num2;
                            break;
                        case '*':
                            ans = num1 * num2;
                            break;
                        case '/':
                            ans = num1 / num2;
                            break;
                    }

                    stack.Push(ans);
                }
                else
                {
                    return double.NaN; // Return NaN to indicate an error
                }
            }

            if (stack.Count == 1)
            {
                return stack.Pop();
            }
            else
            {
                return double.NaN; // Return NaN to indicate an error
            }
        }

        private void inputBtns(object sender, EventArgs e) // Function to handle input button clicks
        {
            textBoxInfix.ForeColor = Color.FromArgb(0, 0, 0);
            textBoxAns.ForeColor = Color.FromArgb(75, 68, 83);
            textBoxInfix.Font = new Font("Segoe UI Black", 29F, FontStyle.Bold);
            textBoxInfix.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold);
            Button inputButtons = sender as Button;
            infixString = inputButtons.Text;
            if ((textBoxInfix.Text.Length == 0) && (infixString == "+" || infixString == "-" || infixString == "*" || infixString == "/"))
            {
                textBoxInfix.Text = "Invalid Format Used";
            }
            else
            {
                textBoxInfix.Text += infixString;
            }
        }

        private void equalBtn(object sender, EventArgs e) // Function to handle the equal button click
        {
            try
            {
                string postfix = InfixToPostfix(textBoxInfix.Text);
                double result = EvaluatePostfix(postfix);
                if (double.IsNaN(result))
                {
                    textBoxAns.Text = "ERROR";
                }
                else
                {
                    textBoxAns.Text = result.ToString();
                    textBoxInfix.Text = result.ToString();
                }
                textBoxInfix.ForeColor = Color.FromArgb(75, 68, 83);
                textBoxAns.ForeColor = Color.FromArgb(0, 0, 0);
                textBoxAns.Font = new Font("Segoe UI Black", 29F, FontStyle.Bold);
                textBoxInfix.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold);
            }
            catch
            {
                textBoxAns.Text = "ERROR";
            }
        }

        private void clearBtn(object sender, EventArgs e) // Function to handle the clear button click
        {
            textBoxInfix.ForeColor = Color.FromArgb(0, 0, 0);
            textBoxInfix.Font = new Font("Segoe UI Black", 29F, FontStyle.Bold);
            textBoxInfix.Font = new Font("Segoe UI Black", 20F, FontStyle.Bold);
            textBoxInfix.Text = string.Empty;
            textBoxAns.Text = string.Empty;
            infixString = "";
        }
    }
}   