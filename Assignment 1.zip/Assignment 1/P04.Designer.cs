﻿namespace Assignment_1
{
    partial class P04
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(P04));
            textBoxInfix = new TextBox();
            textBoxAns = new TextBox();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            button12 = new Button();
            button13 = new Button();
            button14 = new Button();
            button15 = new Button();
            button16 = new Button();
            button17 = new Button();
            button18 = new Button();
            button19 = new Button();
            button20 = new Button();
            pictureBox = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            SuspendLayout();
            // 
            // textBoxInfix
            // 
            textBoxInfix.BackColor = Color.FromArgb(233, 30, 99);
            textBoxInfix.BorderStyle = BorderStyle.None;
            textBoxInfix.Font = new Font("Segoe UI Black", 22F, FontStyle.Bold);
            textBoxInfix.ForeColor = SystemColors.InfoText;
            textBoxInfix.Location = new Point(12, 11);
            textBoxInfix.Name = "textBoxInfix";
            textBoxInfix.Size = new Size(505, 60);
            textBoxInfix.TabIndex = 0;
            textBoxInfix.TextAlign = HorizontalAlignment.Right;
            // 
            // textBoxAns
            // 
            textBoxAns.BackColor = Color.FromArgb(233, 30, 99);
            textBoxAns.BorderStyle = BorderStyle.None;
            textBoxAns.Font = new Font("Segoe UI Black", 22F, FontStyle.Bold);
            textBoxAns.Location = new Point(12, 64);
            textBoxAns.Name = "textBoxAns";
            textBoxAns.Size = new Size(505, 60);
            textBoxAns.TabIndex = 1;
            textBoxAns.TextAlign = HorizontalAlignment.Right;
            // 
            // button1
            // 
            button1.BackColor = Color.Silver;
            button1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button1.Location = new Point(12, 169);
            button1.Name = "button1";
            button1.Size = new Size(118, 100);
            button1.TabIndex = 2;
            button1.Text = "C";
            button1.UseVisualStyleBackColor = false;
            button1.Click += clearBtn;
            // 
            // button2
            // 
            button2.BackColor = Color.Silver;
            button2.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button2.Location = new Point(136, 169);
            button2.Name = "button2";
            button2.Size = new Size(118, 100);
            button2.TabIndex = 3;
            button2.Text = "CE";
            button2.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.Silver;
            button3.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button3.Location = new Point(260, 169);
            button3.Name = "button3";
            button3.Size = new Size(118, 100);
            button3.TabIndex = 4;
            button3.Text = "/";
            button3.UseVisualStyleBackColor = false;
            button3.Click += inputBtns;
            // 
            // button5
            // 
            button5.BackColor = Color.Silver;
            button5.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button5.Location = new Point(392, 169);
            button5.Name = "button5";
            button5.Size = new Size(125, 100);
            button5.TabIndex = 9;
            button5.Text = "*";
            button5.UseVisualStyleBackColor = false;
            button5.Click += inputBtns;
            // 
            // button6
            // 
            button6.BackColor = Color.FromArgb(253, 253, 253);
            button6.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button6.ForeColor = SystemColors.ActiveCaptionText;
            button6.Location = new Point(260, 275);
            button6.Name = "button6";
            button6.Size = new Size(118, 100);
            button6.TabIndex = 8;
            button6.Text = "9";
            button6.UseVisualStyleBackColor = false;
            button6.Click += inputBtns;
            // 
            // button7
            // 
            button7.BackColor = Color.FromArgb(253, 253, 253);
            button7.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button7.ForeColor = SystemColors.ActiveCaptionText;
            button7.Location = new Point(136, 275);
            button7.Name = "button7";
            button7.Size = new Size(118, 100);
            button7.TabIndex = 7;
            button7.Text = "8";
            button7.UseVisualStyleBackColor = false;
            button7.Click += inputBtns;
            // 
            // button8
            // 
            button8.BackColor = Color.FromArgb(253, 253, 253);
            button8.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button8.ForeColor = SystemColors.ActiveCaptionText;
            button8.Location = new Point(12, 275);
            button8.Name = "button8";
            button8.Size = new Size(118, 100);
            button8.TabIndex = 6;
            button8.Text = "7";
            button8.UseVisualStyleBackColor = false;
            button8.Click += inputBtns;
            // 
            // button9
            // 
            button9.BackColor = Color.Silver;
            button9.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button9.Location = new Point(392, 275);
            button9.Name = "button9";
            button9.Size = new Size(125, 100);
            button9.TabIndex = 13;
            button9.Text = "-";
            button9.UseVisualStyleBackColor = false;
            button9.Click += inputBtns;
            // 
            // button10
            // 
            button10.BackColor = Color.FromArgb(253, 253, 253);
            button10.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button10.ForeColor = SystemColors.ActiveCaptionText;
            button10.Location = new Point(260, 381);
            button10.Name = "button10";
            button10.Size = new Size(118, 100);
            button10.TabIndex = 12;
            button10.Text = "6";
            button10.UseVisualStyleBackColor = false;
            button10.Click += inputBtns;
            // 
            // button11
            // 
            button11.BackColor = Color.FromArgb(253, 253, 253);
            button11.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button11.ForeColor = SystemColors.ActiveCaptionText;
            button11.Location = new Point(136, 381);
            button11.Name = "button11";
            button11.Size = new Size(118, 100);
            button11.TabIndex = 11;
            button11.Text = "5";
            button11.UseVisualStyleBackColor = false;
            button11.Click += inputBtns;
            // 
            // button12
            // 
            button12.BackColor = Color.FromArgb(253, 253, 253);
            button12.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button12.ForeColor = SystemColors.ActiveCaptionText;
            button12.Location = new Point(12, 381);
            button12.Name = "button12";
            button12.Size = new Size(118, 100);
            button12.TabIndex = 10;
            button12.Text = "4";
            button12.UseVisualStyleBackColor = false;
            button12.Click += inputBtns;
            // 
            // button13
            // 
            button13.BackColor = Color.Silver;
            button13.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button13.Location = new Point(392, 381);
            button13.Name = "button13";
            button13.Size = new Size(125, 100);
            button13.TabIndex = 17;
            button13.Text = "+";
            button13.UseVisualStyleBackColor = false;
            button13.Click += inputBtns;
            // 
            // button14
            // 
            button14.BackColor = Color.FromArgb(253, 253, 253);
            button14.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button14.ForeColor = SystemColors.ActiveCaptionText;
            button14.Location = new Point(260, 487);
            button14.Name = "button14";
            button14.Size = new Size(118, 100);
            button14.TabIndex = 16;
            button14.Text = "3";
            button14.UseVisualStyleBackColor = false;
            button14.Click += inputBtns;
            // 
            // button15
            // 
            button15.BackColor = Color.FromArgb(253, 253, 253);
            button15.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button15.ForeColor = SystemColors.ActiveCaptionText;
            button15.Location = new Point(136, 487);
            button15.Name = "button15";
            button15.Size = new Size(118, 100);
            button15.TabIndex = 15;
            button15.Text = "2";
            button15.UseVisualStyleBackColor = false;
            button15.Click += inputBtns;
            // 
            // button16
            // 
            button16.BackColor = Color.FromArgb(253, 253, 253);
            button16.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button16.ForeColor = SystemColors.ActiveCaptionText;
            button16.Location = new Point(12, 487);
            button16.Name = "button16";
            button16.Size = new Size(118, 100);
            button16.TabIndex = 14;
            button16.Text = "1";
            button16.UseVisualStyleBackColor = false;
            button16.Click += inputBtns;
            // 
            // button17
            // 
            button17.BackColor = Color.FromArgb(233, 30, 99);
            button17.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button17.ForeColor = SystemColors.ActiveCaptionText;
            button17.Location = new Point(393, 487);
            button17.Name = "button17";
            button17.Size = new Size(125, 206);
            button17.TabIndex = 21;
            button17.Text = "=";
            button17.UseVisualStyleBackColor = false;
            button17.Click += equalBtn;
            // 
            // button18
            // 
            button18.BackColor = Color.FromArgb(253, 253, 253);
            button18.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button18.ForeColor = SystemColors.ActiveCaptionText;
            button18.Location = new Point(260, 593);
            button18.Name = "button18";
            button18.Size = new Size(118, 100);
            button18.TabIndex = 20;
            button18.Text = ".";
            button18.UseVisualStyleBackColor = false;
            button18.Click += inputBtns;
            // 
            // button19
            // 
            button19.BackColor = Color.FromArgb(253, 253, 253);
            button19.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button19.ForeColor = SystemColors.ActiveCaptionText;
            button19.Location = new Point(136, 593);
            button19.Name = "button19";
            button19.Size = new Size(118, 100);
            button19.TabIndex = 19;
            button19.Text = "00";
            button19.UseVisualStyleBackColor = false;
            button19.Click += inputBtns;
            // 
            // button20
            // 
            button20.BackColor = Color.FromArgb(253, 253, 253);
            button20.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold);
            button20.ForeColor = SystemColors.ActiveCaptionText;
            button20.Location = new Point(12, 593);
            button20.Name = "button20";
            button20.Size = new Size(118, 100);
            button20.TabIndex = 18;
            button20.Text = "0";
            button20.UseVisualStyleBackColor = false;
            button20.Click += inputBtns;
            // 
            // pictureBox
            // 
            pictureBox.Dock = DockStyle.Fill;
            pictureBox.Image = (Image)resources.GetObject("pictureBox.Image");
            pictureBox.Location = new Point(0, 0);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(529, 705);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.TabIndex = 22;
            pictureBox.TabStop = false;
            // 
            // P04
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.Control;
            ClientSize = new Size(529, 705);
            Controls.Add(pictureBox);
            Controls.Add(button17);
            Controls.Add(button18);
            Controls.Add(button19);
            Controls.Add(button20);
            Controls.Add(button13);
            Controls.Add(button14);
            Controls.Add(button15);
            Controls.Add(button16);
            Controls.Add(button9);
            Controls.Add(button10);
            Controls.Add(button11);
            Controls.Add(button12);
            Controls.Add(button5);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(button8);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(textBoxAns);
            Controls.Add(textBoxInfix);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "P04";
            Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox textBoxInfix;
        private TextBox textBoxAns;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
        private Button button12;
        private Button button13;
        private Button button14;
        private Button button15;
        private Button button16;
        private Button button17;
        private Button button18;
        private Button button19;
        private Button button20;
        private PictureBox pictureBox;
    }
}