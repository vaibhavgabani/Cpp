﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Forms;
using System.Drawing;

namespace Assignment_1
{
    public partial class P04 : Form
    {
        private string infixString = "";

        public P04()
        {
            InitializeComponent();
            pictureBox.SendToBack();
        }

        private void inputBtns(object sender, EventArgs e)
        {
            Button inputButton = sender as Button;
            if (inputButton != null)
            {
                infixString += inputButton.Text;
                textBoxInfix.Text = infixString;
            }
        }

        private void equalBtn(object sender, EventArgs e)
        {
            try
            {
                double result = EvaluateLeftToRight(infixString);
                textBoxAns.Text = result.ToString();
                textBoxInfix.Text = result.ToString();
            }
            catch
            {
                textBoxAns.Text = "ERROR";
            }
        }

        private double EvaluateLeftToRight(string expression)
        {
            try
            {
                List<string> tokens = new List<string>();
                StringBuilder num = new StringBuilder();

                foreach (char ch in expression)
                {
                    if (char.IsDigit(ch) || ch == '.')
                    {
                        num.Append(ch);
                    }
                    else
                    {
                        if (num.Length > 0)
                        {
                            tokens.Add(num.ToString());
                            num.Clear();
                        }
                        tokens.Add(ch.ToString());
                    }
                }
                if (num.Length > 0)
                {
                    tokens.Add(num.ToString());
                }

                double result = double.Parse(tokens[0]);
                for (int i = 1; i < tokens.Count; i += 2)
                {
                    string op = tokens[i];
                    double nextNum = double.Parse(tokens[i + 1]);

                    switch (op)
                    {
                        case "+": result += nextNum; break;
                        case "-": result -= nextNum; break;
                        case "*": result *= nextNum; break;
                        case "/": result /= nextNum; break;
                    }
                }

                return result;
            }
            catch
            {
                return double.NaN;
            }
        }

        private void clearBtn(object sender, EventArgs e)
        {
            textBoxInfix.Text = string.Empty;
            textBoxAns.Text = string.Empty;
            infixString = "";
        }
    }
}