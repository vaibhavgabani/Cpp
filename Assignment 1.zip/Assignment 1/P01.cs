using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;

namespace Assignment_1
{
    public partial class P01 : Form
    {
        // Alert label for displaying validation messages
        private Label alertLabel = new Label
        {
            ForeColor = Color.Red,
            Font = new System.Drawing.Font("Segoe UI Black", 10F, FontStyle.Bold),
            AutoSize = true,
            Visible = false
        };

        public P01()
        {
            InitializeComponent();
            panel1.Controls.Add(alertLabel); // Add alertLabel to panel1
            emptyLabel();
            flowLayoutPanel1.Hide();
            pictureBox.SendToBack();
        }

        // Clears the result labels
        private void emptyLabel()
        {
            labelRollnoAns.Text = string.Empty;
            labelNameAns.Text = string.Empty;
            labelDivAns.Text = string.Empty;
            labelSemesterAns.Text = string.Empty;
            labelIotAns.Text = string.Empty;
            labelCSAns.Text = string.Empty;
            labelRdbmsAns.Text = string.Empty;
            labelTotalAns.Text = string.Empty;
            labelPersentageAns.Text = string.Empty;
        }

        // Disables all input fields after form submission
        private void disableInput()
        {
            textBoxRollnoIn.Enabled = false;
            textBoxNameIn.Enabled = false;
            textBoxDivIn.Enabled = false;
            textBoxSemIn.Enabled = false;
            textBoxIotIn.Enabled = false;
            textBoxCSIn.Enabled = false;
            textBoxRdbmsIn.Enabled = false;
            submitBtn.Enabled = false;
        }

        private void Submit(object sender, EventArgs e)
        {
            // Clear previous alert
            alertLabel.Text = "";
            alertLabel.Visible = false;

            // Validate Roll Number
            if (string.IsNullOrWhiteSpace(textBoxRollnoIn.Text))
            {
                alertLabel.Text = "Please enter your Roll Number.";
                alertLabel.Location = new Point(381, 56);
                alertLabel.Visible = true;
                return;
            }
            if (!int.TryParse(textBoxRollnoIn.Text, out _))
            {
                alertLabel.Text = "Roll Number must be a valid integer.";
                alertLabel.Location = new Point(381, 56);
                alertLabel.Visible = true;
                return;
            }
            labelRollnoAns.Text = textBoxRollnoIn.Text;

            // Validate Name
            if (string.IsNullOrWhiteSpace(textBoxNameIn.Text))
            {
                alertLabel.Text = "Please enter your Name.";
                alertLabel.Location = new Point(381, 102);
                alertLabel.Visible = true;
                return;
            }
            if (textBoxNameIn.Text.Any(char.IsDigit))
            {
                alertLabel.Text = "Name cannot contain numbers.";
                alertLabel.Location = new Point(381, 102);
                alertLabel.Visible = true;
                return;
            }
            labelNameAns.Text = textBoxNameIn.Text;

            // Validate Division
            if (string.IsNullOrWhiteSpace(textBoxDivIn.Text))
            {
                alertLabel.Text = "Please enter your Division.";
                alertLabel.Location = new Point(381, 151);
                alertLabel.Visible = true;
                return;
            }
            if (textBoxDivIn.Text.Any(char.IsDigit))
            {
                alertLabel.Text = "Division cannot contain numbers.";
                alertLabel.Location = new Point(381, 151);
                alertLabel.Visible = true;
                return;
            }
            labelDivAns.Text = textBoxDivIn.Text;

            // Validate Semester
            if (string.IsNullOrWhiteSpace(textBoxSemIn.Text))
            {
                alertLabel.Text = "Please enter your Semester.";
                alertLabel.Location = new Point(381, 200);
                alertLabel.Visible = true;
                return;
            }
            if (!int.TryParse(textBoxSemIn.Text, out _))
            {
                alertLabel.Text = "Semester must be a valid integer.";
                alertLabel.Location = new Point(381, 200);
                alertLabel.Visible = true;
                return;
            }
            labelSemesterAns.Text = textBoxSemIn.Text;

            // Validate IoT Marks (0-100)
            if (string.IsNullOrWhiteSpace(textBoxIotIn.Text))
            {
                alertLabel.Text = "Please enter your IoT marks.";
                alertLabel.Location = new Point(381, 249);
                alertLabel.Visible = true;
                return;
            }
            if (!int.TryParse(textBoxIotIn.Text, out int iotMarks) || iotMarks < 0 || iotMarks > 100)
            {
                alertLabel.Text = "IoT marks must be between 0 and 100.";
                alertLabel.Location = new Point(381, 249);
                alertLabel.Visible = true;
                return;
            }
            labelIotAns.Text = textBoxIotIn.Text;

            // Validate RDBMS Marks (0-100)
            if (string.IsNullOrWhiteSpace(textBoxRdbmsIn.Text))
            {
                alertLabel.Text = "Please enter your RDBMS marks.";
                alertLabel.Location = new Point(381, 293);
                alertLabel.Visible = true;
                return;
            }
            if (!int.TryParse(textBoxRdbmsIn.Text, out int rdbmsMarks) || rdbmsMarks < 0 || rdbmsMarks > 100)
            {
                alertLabel.Text = "RDBMS marks must be between 0 and 100.";
                alertLabel.Location = new Point(381, 293);
                alertLabel.Visible = true;
                return;
            }
            labelRdbmsAns.Text = textBoxRdbmsIn.Text;

            // Validate CS Marks (0-100)
            if (string.IsNullOrWhiteSpace(textBoxCSIn.Text))
            {
                alertLabel.Text = "Please enter your CS marks.";
                alertLabel.Location = new Point(381, 345);
                alertLabel.Visible = true;
                return;
            }
            if (!int.TryParse(textBoxCSIn.Text, out int csMarks) || csMarks < 0 || csMarks > 100)
            {
                alertLabel.Text = "CS marks must be between 0 and 100.";
                alertLabel.Location = new Point(381, 345);
                alertLabel.Visible = true;
                return;
            }
            labelCSAns.Text = textBoxCSIn.Text;

            // Calculate total marks and percentage
            int totalMarks = iotMarks + csMarks + rdbmsMarks;
            labelTotalAns.Text = totalMarks.ToString();
            labelPersentageAns.Text = ((totalMarks * 100) / 300).ToString("F2");

            // Show result panel and disable inputs
            flowLayoutPanel1.Show();
            pictureBox.Visible = false;
            disableInput();
            this.Width = 1279;
        }

        private void Reset(object sender, EventArgs e)
        {
            // Reset input fields
            textBoxRollnoIn.Text = string.Empty;
            textBoxNameIn.Text = string.Empty;
            textBoxDivIn.Text = string.Empty;
            textBoxSemIn.Text = string.Empty;
            textBoxIotIn.Text = string.Empty;
            textBoxCSIn.Text = string.Empty;
            textBoxRdbmsIn.Text = string.Empty;

            emptyLabel();
            submitBtn.Enabled = true;
            this.Width = 831;
            pictureBox.Visible = true;

            // Hide alert and result panel
            alertLabel.Text = "";
            alertLabel.Visible = false;
            flowLayoutPanel1.Hide();
        }
    }
}
