namespace Assignment_1
{
    public partial class P01 : Form
    {
        private Label alertLabel;

        public P01()
        {
            InitializeComponent();
            emptyLabel();
            flowLayoutPanel1.Hide();
            InitializeAlertLabel(); // Initialize the alert label
        }

        private void emptyLabel()
        {
            labelRollnoAns.Text = string.Empty;
            labelNameAns.Text = string.Empty;
            labelDivAns.Text = string.Empty;
            labelSemesterAns.Text = string.Empty;
            labelIotAns.Text = string.Empty;
            labelCSAns.Text = string.Empty;
            labelRdbmsAns.Text = string.Empty;
            labelTotalAns.Text = string.Empty;
            labelPersentageAns.Text = string.Empty;
        }

        private void disableInput()
        {
            textBoxRollnoIn.Enabled = false;
            textBoxNameIn.Enabled = false;
            textBoxDivIn.Enabled = false;
            textBoxSemIn.Enabled = false;
            textBoxIotIn.Enabled = false;
            textBoxCSIn.Enabled = false;
            textBoxRdbmsIn.Enabled = false;
            submitBtn.Enabled = false;
        }

        private void InitializeAlertLabel()
        {
            alertLabel = new Label
            {
                ForeColor = Color.Red,
                Font = new System.Drawing.Font("Segoe UI Black", 10F, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(381, 56),
                Visible = false
            };
            panel1.Controls.Add(alertLabel); // Add the alert label to the panel
        }

        private void ShowAlert(string message, int x, int y, bool isVisible)
        {
            alertLabel.Text = message;
            alertLabel.Location = new Point(x, y);
            alertLabel.Visible = isVisible;
        }

        private void Submit(object sender, EventArgs e)
        {
            // Clear previous message first
            ShowAlert("", 381, 56, false);

            // Check input of rollno
            if (string.IsNullOrWhiteSpace(textBoxRollnoIn.Text))
            {
                ShowAlert("Please enter your Roll Number.", 381, 56, true);
                return;
            }
            if (!int.TryParse(textBoxRollnoIn.Text, out _))
            {
                ShowAlert("Roll Number must be a valid integer.", 381, 56, true);
                return;
            }
            labelRollnoAns.Text = textBoxRollnoIn.Text;

            // Check input for Name
            if (string.IsNullOrWhiteSpace(textBoxNameIn.Text))
            {
                ShowAlert("Please enter your Name.", 381, 102, true);
                return;
            }
            if (textBoxNameIn.Text.Any(char.IsDigit))
            {
                ShowAlert("Name cannot contain numbers.", 381, 102, true);
                return;
            }
            labelNameAns.Text = textBoxNameIn.Text;

            // Check input for Div
            if (string.IsNullOrWhiteSpace(textBoxDivIn.Text))
            {
                ShowAlert("Please enter your Division.", 381, 151, true);
                return;
            }
            if (textBoxDivIn.Text.Any(char.IsDigit))
            {
                ShowAlert("Division cannot contain numbers.", 381, 151, true);
                return;
            }
            labelDivAns.Text = textBoxDivIn.Text;

            // Check input for Semester
            if (string.IsNullOrWhiteSpace(textBoxSemIn.Text))
            {
                ShowAlert("Please enter your Semester.", 381, 200, true);
                return;
            }
            if (!int.TryParse(textBoxSemIn.Text, out _))
            {
                ShowAlert("Semester must be a valid integer.", 381, 200, true);
                return;
            }
            labelSemesterAns.Text = textBoxSemIn.Text;

            // Check input for IoT
            if (string.IsNullOrWhiteSpace(textBoxIotIn.Text))
            {
                ShowAlert("Please enter your IoT marks.", 381, 249, true);
                return;
            }
            if (!int.TryParse(textBoxIotIn.Text, out int iotMarks) || iotMarks < 0 || iotMarks > 100)
            {
                ShowAlert("IoT marks must be between 0 and 100.", 381, 249, true);
                return;
            }
            labelIotAns.Text = textBoxIotIn.Text;

            // Check input for RDBMS
            if (string.IsNullOrWhiteSpace(textBoxRdbmsIn.Text))
            {
                ShowAlert("Please enter your RDBMS marks.", 381, 293, true);
                return;
            }
            if (!int.TryParse(textBoxRdbmsIn.Text, out int rdbmsMarks) || rdbmsMarks < 0 || rdbmsMarks > 100)
            {
                ShowAlert("RDBMS marks must be between 0 and 100.", 381, 293, true);
                return;
            }
            labelRdbmsAns.Text = textBoxRdbmsIn.Text;

            // Check input for CS
            if (string.IsNullOrWhiteSpace(textBoxCSIn.Text))
            {
                ShowAlert("Please enter your CS marks.", 381, 345, true);
                return;
            }
            if (!int.TryParse(textBoxCSIn.Text, out int csMarks) || csMarks < 0 || csMarks > 100)
            {
                ShowAlert("CS marks must be between 0 and 100.", 381, 345, true);
                return;
            }
            labelCSAns.Text = textBoxCSIn.Text;

            // Calculate total and percentage
            labelTotalAns.Text = (iotMarks + csMarks + rdbmsMarks).ToString();
            labelPersentageAns.Text = ((iotMarks + csMarks + rdbmsMarks) * 100 / 300).ToString("F2");
            flowLayoutPanel1.Show();
            disableInput();
            this.Width = 1279;
        }

        private void Reset(object sender, EventArgs e)
        {
            textBoxRollnoIn.Text = string.Empty;
            textBoxNameIn.Text = string.Empty;
            textBoxDivIn.Text = string.Empty;
            textBoxSemIn.Text = string.Empty;
            textBoxIotIn.Text = string.Empty;
            textBoxCSIn.Text = string.Empty;
            textBoxRdbmsIn.Text = string.Empty;

            emptyLabel();
            submitBtn.Enabled = true;
            this.Width = 831;
            ShowAlert("", 381, 56, false); // Hide alert label on reset
            flowLayoutPanel1.Hide();
        }
    }
}