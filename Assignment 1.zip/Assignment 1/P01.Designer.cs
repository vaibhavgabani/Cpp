﻿namespace Assignment_1
{
    partial class P01
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(P01));
            panel1 = new Panel();
            button2 = new Button();
            submitBtn = new Button();
            flowLayoutPanel1 = new FlowLayoutPanel();
            label14 = new Label();
            label13 = new Label();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label8 = new Label();
            label9 = new Label();
            label15 = new Label();
            label16 = new Label();
            labelRollnoAns = new Label();
            labelNameAns = new Label();
            labelDivAns = new Label();
            labelSemesterAns = new Label();
            labelIotAns = new Label();
            labelRdbmsAns = new Label();
            labelCSAns = new Label();
            labelTotalAns = new Label();
            labelPersentageAns = new Label();
            textBoxCSIn = new TextBox();
            textBoxRdbmsIn = new TextBox();
            textBoxIotIn = new TextBox();
            textBoxSemIn = new TextBox();
            textBoxDivIn = new TextBox();
            textBoxNameIn = new TextBox();
            textBoxRollnoIn = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            pictureBox = new PictureBox();
            panel1.SuspendLayout();
            flowLayoutPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(242, 239, 231);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(submitBtn);
            panel1.Controls.Add(flowLayoutPanel1);
            panel1.Controls.Add(textBoxCSIn);
            panel1.Controls.Add(textBoxRdbmsIn);
            panel1.Controls.Add(textBoxIotIn);
            panel1.Controls.Add(textBoxSemIn);
            panel1.Controls.Add(textBoxDivIn);
            panel1.Controls.Add(textBoxNameIn);
            panel1.Controls.Add(textBoxRollnoIn);
            panel1.Controls.Add(label7);
            panel1.Controls.Add(label6);
            panel1.Controls.Add(label5);
            panel1.Controls.Add(label4);
            panel1.Controls.Add(label3);
            panel1.Controls.Add(label2);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(pictureBox);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(809, 554);
            panel1.TabIndex = 0;
            // 
            // button2
            // 
            button2.Font = new Font("Arial Rounded MT Bold", 18F);
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.Location = new Point(202, 422);
            button2.Name = "button2";
            button2.Size = new Size(155, 88);
            button2.TabIndex = 16;
            button2.Text = "Reset";
            button2.UseVisualStyleBackColor = true;
            button2.Click += Reset;
            // 
            // submitBtn
            // 
            submitBtn.Font = new Font("Arial Rounded MT Bold", 18F);
            submitBtn.Image = (Image)resources.GetObject("submitBtn.Image");
            submitBtn.Location = new Point(31, 422);
            submitBtn.Name = "submitBtn";
            submitBtn.Size = new Size(165, 88);
            submitBtn.TabIndex = 15;
            submitBtn.Text = "Submit";
            submitBtn.UseVisualStyleBackColor = true;
            submitBtn.Click += Submit;
            // 
            // flowLayoutPanel1
            // 
            flowLayoutPanel1.BackColor = Color.FromArgb(154, 203, 208);
            flowLayoutPanel1.BorderStyle = BorderStyle.FixedSingle;
            flowLayoutPanel1.Controls.Add(label14);
            flowLayoutPanel1.Controls.Add(label13);
            flowLayoutPanel1.Controls.Add(label12);
            flowLayoutPanel1.Controls.Add(label11);
            flowLayoutPanel1.Controls.Add(label10);
            flowLayoutPanel1.Controls.Add(label8);
            flowLayoutPanel1.Controls.Add(label9);
            flowLayoutPanel1.Controls.Add(label15);
            flowLayoutPanel1.Controls.Add(label16);
            flowLayoutPanel1.Controls.Add(labelRollnoAns);
            flowLayoutPanel1.Controls.Add(labelNameAns);
            flowLayoutPanel1.Controls.Add(labelDivAns);
            flowLayoutPanel1.Controls.Add(labelSemesterAns);
            flowLayoutPanel1.Controls.Add(labelIotAns);
            flowLayoutPanel1.Controls.Add(labelRdbmsAns);
            flowLayoutPanel1.Controls.Add(labelCSAns);
            flowLayoutPanel1.Controls.Add(labelTotalAns);
            flowLayoutPanel1.Controls.Add(labelPersentageAns);
            flowLayoutPanel1.Location = new Point(383, 53);
            flowLayoutPanel1.Name = "flowLayoutPanel1";
            flowLayoutPanel1.Size = new Size(830, 457);
            flowLayoutPanel1.TabIndex = 14;
            flowLayoutPanel1.Visible = false;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label14.Location = new Point(3, 0);
            label14.Name = "label14";
            label14.Size = new Size(77, 28);
            label14.TabIndex = 15;
            label14.Text = "Rollno";
            // 
            // label13
            // 
            label13.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label13.Location = new Point(86, 0);
            label13.MinimumSize = new Size(20, 0);
            label13.Name = "label13";
            label13.Size = new Size(135, 28);
            label13.TabIndex = 16;
            label13.Text = "Name";
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label12.Location = new Point(227, 0);
            label12.Name = "label12";
            label12.Size = new Size(45, 28);
            label12.TabIndex = 17;
            label12.Text = "Div";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label11.Location = new Point(278, 0);
            label11.Name = "label11";
            label11.Size = new Size(102, 28);
            label11.TabIndex = 18;
            label11.Text = "Semester";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label10.Location = new Point(386, 0);
            label10.Name = "label10";
            label10.Size = new Size(47, 28);
            label10.TabIndex = 19;
            label10.Text = "IOT";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label8.Location = new Point(439, 0);
            label8.Name = "label8";
            label8.Size = new Size(86, 28);
            label8.TabIndex = 21;
            label8.Text = "RDBMS";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label9.Location = new Point(531, 0);
            label9.Name = "label9";
            label9.Size = new Size(83, 28);
            label9.TabIndex = 20;
            label9.Text = "C#.NET";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label15.Location = new Point(620, 0);
            label15.Name = "label15";
            label15.Size = new Size(63, 28);
            label15.TabIndex = 22;
            label15.Text = "Total";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label16.Location = new Point(689, 0);
            label16.Name = "label16";
            label16.Size = new Size(122, 28);
            label16.TabIndex = 23;
            label16.Text = "Percentage";
            // 
            // labelRollnoAns
            // 
            labelRollnoAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelRollnoAns.Location = new Point(3, 28);
            labelRollnoAns.Name = "labelRollnoAns";
            labelRollnoAns.Size = new Size(77, 28);
            labelRollnoAns.TabIndex = 24;
            labelRollnoAns.Text = "Rollno";
            // 
            // labelNameAns
            // 
            labelNameAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelNameAns.Location = new Point(86, 28);
            labelNameAns.MinimumSize = new Size(20, 0);
            labelNameAns.Name = "labelNameAns";
            labelNameAns.Size = new Size(135, 28);
            labelNameAns.TabIndex = 25;
            labelNameAns.Text = "Name";
            // 
            // labelDivAns
            // 
            labelDivAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelDivAns.Location = new Point(227, 28);
            labelDivAns.Name = "labelDivAns";
            labelDivAns.Size = new Size(45, 28);
            labelDivAns.TabIndex = 26;
            labelDivAns.Text = "Div";
            // 
            // labelSemesterAns
            // 
            labelSemesterAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelSemesterAns.Location = new Point(278, 28);
            labelSemesterAns.Name = "labelSemesterAns";
            labelSemesterAns.Size = new Size(102, 28);
            labelSemesterAns.TabIndex = 27;
            labelSemesterAns.Text = "Semester";
            // 
            // labelIotAns
            // 
            labelIotAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelIotAns.Location = new Point(386, 28);
            labelIotAns.Name = "labelIotAns";
            labelIotAns.Size = new Size(47, 28);
            labelIotAns.TabIndex = 28;
            labelIotAns.Text = "IOT";
            // 
            // labelRdbmsAns
            // 
            labelRdbmsAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelRdbmsAns.Location = new Point(439, 28);
            labelRdbmsAns.Name = "labelRdbmsAns";
            labelRdbmsAns.Size = new Size(86, 28);
            labelRdbmsAns.TabIndex = 30;
            labelRdbmsAns.Text = "RDBMS";
            // 
            // labelCSAns
            // 
            labelCSAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelCSAns.Location = new Point(531, 28);
            labelCSAns.Name = "labelCSAns";
            labelCSAns.Size = new Size(83, 28);
            labelCSAns.TabIndex = 29;
            labelCSAns.Text = "C#.NET";
            // 
            // labelTotalAns
            // 
            labelTotalAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelTotalAns.Location = new Point(620, 28);
            labelTotalAns.Name = "labelTotalAns";
            labelTotalAns.Size = new Size(63, 28);
            labelTotalAns.TabIndex = 31;
            labelTotalAns.Text = "Total";
            // 
            // labelPersentageAns
            // 
            labelPersentageAns.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            labelPersentageAns.Location = new Point(689, 28);
            labelPersentageAns.Name = "labelPersentageAns";
            labelPersentageAns.Size = new Size(122, 28);
            labelPersentageAns.TabIndex = 32;
            labelPersentageAns.Text = "Percentage";
            // 
            // textBoxCSIn
            // 
            textBoxCSIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxCSIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxCSIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxCSIn.Location = new Point(170, 343);
            textBoxCSIn.Name = "textBoxCSIn";
            textBoxCSIn.Size = new Size(187, 35);
            textBoxCSIn.TabIndex = 13;
            // 
            // textBoxRdbmsIn
            // 
            textBoxRdbmsIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxRdbmsIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxRdbmsIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxRdbmsIn.Location = new Point(170, 291);
            textBoxRdbmsIn.Name = "textBoxRdbmsIn";
            textBoxRdbmsIn.Size = new Size(187, 35);
            textBoxRdbmsIn.TabIndex = 12;
            // 
            // textBoxIotIn
            // 
            textBoxIotIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxIotIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxIotIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxIotIn.Location = new Point(170, 245);
            textBoxIotIn.Name = "textBoxIotIn";
            textBoxIotIn.Size = new Size(187, 35);
            textBoxIotIn.TabIndex = 11;
            // 
            // textBoxSemIn
            // 
            textBoxSemIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxSemIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxSemIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxSemIn.Location = new Point(170, 195);
            textBoxSemIn.Name = "textBoxSemIn";
            textBoxSemIn.Size = new Size(187, 35);
            textBoxSemIn.TabIndex = 10;
            // 
            // textBoxDivIn
            // 
            textBoxDivIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxDivIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxDivIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxDivIn.Location = new Point(170, 146);
            textBoxDivIn.Name = "textBoxDivIn";
            textBoxDivIn.Size = new Size(187, 35);
            textBoxDivIn.TabIndex = 9;
            // 
            // textBoxNameIn
            // 
            textBoxNameIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxNameIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxNameIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxNameIn.Location = new Point(170, 97);
            textBoxNameIn.Name = "textBoxNameIn";
            textBoxNameIn.Size = new Size(187, 35);
            textBoxNameIn.TabIndex = 8;
            // 
            // textBoxRollnoIn
            // 
            textBoxRollnoIn.BackColor = Color.FromArgb(154, 203, 208);
            textBoxRollnoIn.BorderStyle = BorderStyle.FixedSingle;
            textBoxRollnoIn.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            textBoxRollnoIn.Location = new Point(170, 51);
            textBoxRollnoIn.Name = "textBoxRollnoIn";
            textBoxRollnoIn.Size = new Size(187, 35);
            textBoxRollnoIn.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label7.Location = new Point(31, 290);
            label7.Name = "label7";
            label7.Size = new Size(86, 28);
            label7.TabIndex = 6;
            label7.Text = "RDBMS";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label6.Location = new Point(31, 342);
            label6.Name = "label6";
            label6.Size = new Size(83, 28);
            label6.TabIndex = 5;
            label6.Text = "C#.NET";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label5.Location = new Point(31, 244);
            label5.Name = "label5";
            label5.Size = new Size(47, 28);
            label5.TabIndex = 4;
            label5.Text = "IOT";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label4.Location = new Point(31, 194);
            label4.Name = "label4";
            label4.Size = new Size(102, 28);
            label4.TabIndex = 3;
            label4.Text = "Semester";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label3.Location = new Point(31, 148);
            label3.Name = "label3";
            label3.Size = new Size(45, 28);
            label3.TabIndex = 2;
            label3.Text = "Div";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label2.Location = new Point(31, 96);
            label2.Name = "label2";
            label2.Size = new Size(69, 28);
            label2.TabIndex = 1;
            label2.Text = "Name";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 10F, FontStyle.Bold);
            label1.Location = new Point(31, 50);
            label1.Name = "label1";
            label1.Size = new Size(77, 28);
            label1.TabIndex = 0;
            label1.Text = "Rollno";
            // 
            // pictureBox
            // 
            pictureBox.Image = (Image)resources.GetObject("pictureBox.Image");
            pictureBox.Location = new Point(427, 194);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(385, 360);
            pictureBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox.TabIndex = 17;
            pictureBox.TabStop = false;
            // 
            // P01
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(809, 554);
            Controls.Add(panel1);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "P01";
            Text = "Registration form of student";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            flowLayoutPanel1.ResumeLayout(false);
            flowLayoutPanel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label label1;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox textBoxNameIn;
        private TextBox textBoxRollnoIn;
        private TextBox textBoxRdbmsIn;
        private TextBox textBoxIotIn;
        private TextBox textBoxSemIn;
        private TextBox textBoxDivIn;
        private TextBox textBoxCSIn;
        private FlowLayoutPanel flowLayoutPanel1;
        private Label label14;
        private Label label13;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label8;
        private Label label9;
        private Button button2;
        private Button submitBtn;
        private Label label15;
        private Label label16;
        private Label labelRollnoAns;
        private Label labelNameAns;
        private Label labelDivAns;
        private Label labelSemesterAns;
        private Label labelIotAns;
        private Label labelRdbmsAns;
        private Label labelCSAns;
        private Label labelTotalAns;
        private Label labelPersentageAns;
        private PictureBox pictureBox;
    }
}
