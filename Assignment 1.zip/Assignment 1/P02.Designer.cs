﻿namespace Assignment_1
{
    partial class P02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(P02));
            button2 = new Button();
            button1 = new Button();
            monthCalendar = new MonthCalendar();
            pictureBox1 = new PictureBox();
            YearLabel = new Label();
            Monthlabel = new Label();
            DayLabel = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button2
            // 
            button2.BackgroundImage = (Image)resources.GetObject("button2.BackgroundImage");
            button2.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold);
            button2.Location = new Point(883, 436);
            button2.Name = "button2";
            button2.Size = new Size(182, 69);
            button2.TabIndex = 23;
            button2.Text = "RESET";
            button2.UseVisualStyleBackColor = true;
            button2.Click += resetBtn;
            // 
            // button1
            // 
            button1.BackgroundImage = (Image)resources.GetObject("button1.BackgroundImage");
            button1.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold);
            button1.Location = new Point(698, 436);
            button1.Name = "button1";
            button1.Size = new Size(179, 69);
            button1.TabIndex = 22;
            button1.Text = "SUBMIT";
            button1.UseVisualStyleBackColor = true;
            button1.Click += submitBtn;
            // 
            // monthCalendar
            // 
            monthCalendar.Location = new Point(200, 177);
            monthCalendar.Name = "monthCalendar";
            monthCalendar.TabIndex = 21;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(50, 93);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(588, 412);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 20;
            pictureBox1.TabStop = false;
            // 
            // YearLabel
            // 
            YearLabel.AutoSize = true;
            YearLabel.Font = new Font("Arial Rounded MT Bold", 22F);
            YearLabel.Location = new Point(872, 321);
            YearLabel.Name = "YearLabel";
            YearLabel.Size = new Size(152, 51);
            YearLabel.TabIndex = 19;
            YearLabel.Text = "label4";
            YearLabel.Visible = false;
            // 
            // Monthlabel
            // 
            Monthlabel.AutoSize = true;
            Monthlabel.Font = new Font("Arial Rounded MT Bold", 22F);
            Monthlabel.Location = new Point(872, 243);
            Monthlabel.Name = "Monthlabel";
            Monthlabel.Size = new Size(152, 51);
            Monthlabel.TabIndex = 18;
            Monthlabel.Text = "label5";
            Monthlabel.Visible = false;
            // 
            // DayLabel
            // 
            DayLabel.AutoSize = true;
            DayLabel.Font = new Font("Arial Rounded MT Bold", 22F);
            DayLabel.Location = new Point(872, 163);
            DayLabel.Name = "DayLabel";
            DayLabel.Size = new Size(152, 51);
            DayLabel.TabIndex = 17;
            DayLabel.Text = "label6";
            DayLabel.Visible = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Rounded MT Bold", 22F);
            label3.Location = new Point(685, 321);
            label3.Name = "label3";
            label3.Size = new Size(157, 51);
            label3.TabIndex = 16;
            label3.Text = "Year : ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Arial Rounded MT Bold", 22F);
            label2.Location = new Point(685, 243);
            label2.Name = "label2";
            label2.Size = new Size(192, 51);
            label2.TabIndex = 15;
            label2.Text = "Month : ";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Rounded MT Bold", 22F);
            label1.Location = new Point(685, 163);
            label1.Name = "label1";
            label1.Size = new Size(148, 51);
            label1.TabIndex = 14;
            label1.Text = "Date :";
            // 
            // P02
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1142, 598);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(monthCalendar);
            Controls.Add(pictureBox1);
            Controls.Add(YearLabel);
            Controls.Add(Monthlabel);
            Controls.Add(DayLabel);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "P02";
            Text = "Calander";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button2;
        private Button button1;
        private MonthCalendar monthCalendar;
        private PictureBox pictureBox1;
        private Label YearLabel;
        private Label Monthlabel;
        private Label DayLabel;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}