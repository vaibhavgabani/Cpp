﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_1
{
    public partial class P02 : Form
    {

        private void hideLabels()
        {
            DayLabel.Visible = false; Monthlabel.Visible = false; YearLabel.Visible = false;
        }

        private void showLabels()
        {
            DayLabel.Visible = true; Monthlabel.Visible = true; YearLabel.Visible = true;
        }
        public P02()
        {
            InitializeComponent();
            pictureBox1.SendToBack();
        }

        private void submitBtn(object sender, EventArgs e)
        {
            showLabels();
            DateTime seleactedDate = monthCalendar.SelectionStart;
            DayLabel.Text = seleactedDate.Day.ToString();
            Monthlabel.Text = seleactedDate.ToString("MMMM");
            YearLabel.Text = seleactedDate.Year.ToString();
        }

        private void resetBtn(object sender, EventArgs e)
        {
            hideLabels();
        }      
    }
}
