﻿namespace WinFormsApp1
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            panel1 = new Panel();
            labelUserName = new Label();
            button10 = new Button();
            label1 = new Label();
            button9 = new Button();
            button8 = new Button();
            button7 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.Controls.Add(labelUserName);
            panel1.Controls.Add(button10);
            panel1.Controls.Add(label1);
            panel1.Controls.Add(button9);
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button7);
            panel1.Controls.Add(button6);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Dock = DockStyle.Fill;
            panel1.Location = new Point(0, 0);
            panel1.Name = "panel1";
            panel1.Size = new Size(869, 826);
            panel1.TabIndex = 0;
            // 
            // labelUserName
            // 
            labelUserName.AutoSize = true;
            labelUserName.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelUserName.Location = new Point(418, 721);
            labelUserName.Name = "labelUserName";
            labelUserName.Size = new Size(0, 48);
            labelUserName.TabIndex = 22;
            // 
            // button10
            // 
            button10.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button10.Location = new Point(508, 716);
            button10.Name = "button10";
            button10.Size = new Size(211, 72);
            button10.TabIndex = 21;
            button10.Text = "RESTART";
            button10.UseVisualStyleBackColor = true;
            button10.Click += restartBtn;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(140, 721);
            label1.Name = "label1";
            label1.Size = new Size(278, 48);
            label1.TabIndex = 20;
            label1.Text = "Current User : ";
            // 
            // button9
            // 
            button9.Font = new Font("Arial Rounded MT Bold", 48F);
            button9.Location = new Point(541, 490);
            button9.Name = "button9";
            button9.Size = new Size(178, 175);
            button9.TabIndex = 19;
            button9.TabStop = false;
            button9.UseVisualStyleBackColor = true;
            button9.Click += buttonClick;
            // 
            // button8
            // 
            button8.Font = new Font("Arial Rounded MT Bold", 48F);
            button8.Location = new Point(343, 490);
            button8.Name = "button8";
            button8.Size = new Size(178, 175);
            button8.TabIndex = 18;
            button8.TabStop = false;
            button8.UseVisualStyleBackColor = true;
            button8.Click += buttonClick;
            // 
            // button7
            // 
            button7.Font = new Font("Arial Rounded MT Bold", 48F);
            button7.Location = new Point(140, 490);
            button7.Name = "button7";
            button7.Size = new Size(178, 175);
            button7.TabIndex = 17;
            button7.TabStop = false;
            button7.UseVisualStyleBackColor = true;
            button7.Click += buttonClick;
            // 
            // button6
            // 
            button6.Font = new Font("Arial Rounded MT Bold", 48F);
            button6.Location = new Point(541, 297);
            button6.Name = "button6";
            button6.Size = new Size(178, 175);
            button6.TabIndex = 16;
            button6.TabStop = false;
            button6.UseVisualStyleBackColor = true;
            button6.Click += buttonClick;
            // 
            // button5
            // 
            button5.Font = new Font("Arial Rounded MT Bold", 48F);
            button5.Location = new Point(343, 297);
            button5.Name = "button5";
            button5.Size = new Size(178, 175);
            button5.TabIndex = 15;
            button5.TabStop = false;
            button5.UseVisualStyleBackColor = true;
            button5.Click += buttonClick;
            // 
            // button4
            // 
            button4.Font = new Font("Arial Rounded MT Bold", 48F);
            button4.Location = new Point(140, 297);
            button4.Name = "button4";
            button4.Size = new Size(178, 175);
            button4.TabIndex = 14;
            button4.TabStop = false;
            button4.UseVisualStyleBackColor = true;
            button4.Click += buttonClick;
            // 
            // button3
            // 
            button3.Font = new Font("Arial Rounded MT Bold", 48F);
            button3.Location = new Point(541, 103);
            button3.Name = "button3";
            button3.Size = new Size(178, 175);
            button3.TabIndex = 13;
            button3.TabStop = false;
            button3.UseVisualStyleBackColor = true;
            button3.Click += buttonClick;
            // 
            // button2
            // 
            button2.Font = new Font("Arial Rounded MT Bold", 48F);
            button2.Location = new Point(343, 103);
            button2.Name = "button2";
            button2.Size = new Size(178, 175);
            button2.TabIndex = 12;
            button2.TabStop = false;
            button2.UseVisualStyleBackColor = true;
            button2.Click += buttonClick;
            // 
            // button1
            // 
            button1.Font = new Font("Arial Rounded MT Bold", 48F, FontStyle.Regular, GraphicsUnit.Point, 0);
            button1.ForeColor = Color.Black;
            button1.Location = new Point(140, 103);
            button1.Name = "button1";
            button1.Size = new Size(178, 175);
            button1.TabIndex = 11;
            button1.TabStop = false;
            button1.UseVisualStyleBackColor = true;
            button1.Click += buttonClick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(869, 826);
            Controls.Add(panel1);
            Name = "Form1";
            Text = "Form1";
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel1;
        private Label labelUserName;
        private Button button10;
        private Label label1;
        private Button button9;
        private Button button8;
        private Button button7;
        private Button button6;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
    }
}
