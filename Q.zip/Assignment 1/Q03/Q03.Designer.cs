﻿namespace P03
{
    partial class Q03
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Q03));
            lblAmount = new Label();
            groupBox1 = new GroupBox();
            rbCOD = new RadioButton();
            rbNet = new RadioButton();
            rbDebit = new RadioButton();
            rbCredit = new RadioButton();
            rbSBI = new RadioButton();
            txtAmount = new TextBox();
            label1 = new Label();
            lbls = new Label();
            lblSelect = new Label();
            cmbDebit = new ComboBox();
            cmbCredit = new ComboBox();
            lblSelection = new Label();
            txtAns = new TextBox();
            label3 = new Label();
            btnCalculate = new Button();
            button1 = new Button();
            panel = new Panel();
            pictureBox1 = new PictureBox();
            groupBox1.SuspendLayout();
            panel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // lblAmount
            // 
            lblAmount.AutoSize = true;
            lblAmount.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblAmount.ForeColor = Color.Red;
            lblAmount.Location = new Point(227, 78);
            lblAmount.Name = "lblAmount";
            lblAmount.Size = new Size(0, 30);
            lblAmount.TabIndex = 14;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(rbCOD);
            groupBox1.Controls.Add(rbNet);
            groupBox1.Controls.Add(rbDebit);
            groupBox1.Controls.Add(rbCredit);
            groupBox1.Controls.Add(rbSBI);
            groupBox1.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            groupBox1.Location = new Point(33, 111);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(336, 212);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Payment Methods";
            // 
            // rbCOD
            // 
            rbCOD.AutoSize = true;
            rbCOD.Location = new Point(52, 173);
            rbCOD.Name = "rbCOD";
            rbCOD.Size = new Size(240, 29);
            rbCOD.TabIndex = 6;
            rbCOD.TabStop = true;
            rbCOD.Text = "COD (Cash On Delivery)";
            rbCOD.UseVisualStyleBackColor = true;
            rbCOD.CheckedChanged += rbCODCheckedChanged;
            // 
            // rbNet
            // 
            rbNet.AutoSize = true;
            rbNet.Location = new Point(52, 138);
            rbNet.Name = "rbNet";
            rbNet.Size = new Size(271, 29);
            rbNet.TabIndex = 5;
            rbNet.TabStop = true;
            rbNet.Text = "Net Bankkng (5% discount)";
            rbNet.UseVisualStyleBackColor = true;
            rbNet.CheckedChanged += rbNetCheckedChanged;
            // 
            // rbDebit
            // 
            rbDebit.AutoSize = true;
            rbDebit.Location = new Point(52, 103);
            rbDebit.Name = "rbDebit";
            rbDebit.Size = new Size(227, 29);
            rbDebit.TabIndex = 4;
            rbDebit.TabStop = true;
            rbDebit.Text = "Debit Card (upto 15%)";
            rbDebit.UseVisualStyleBackColor = true;
            rbDebit.CheckedChanged += rbDebitCheckedChanged;
            // 
            // rbCredit
            // 
            rbCredit.AutoSize = true;
            rbCredit.Location = new Point(52, 68);
            rbCredit.Name = "rbCredit";
            rbCredit.Size = new Size(237, 29);
            rbCredit.TabIndex = 1;
            rbCredit.TabStop = true;
            rbCredit.Text = "Credit Card ( upto 20%)";
            rbCredit.UseVisualStyleBackColor = true;
            rbCredit.CheckedChanged += rbCreditCheckedChanged;
            // 
            // rbSBI
            // 
            rbSBI.AutoSize = true;
            rbSBI.Location = new Point(52, 33);
            rbSBI.Name = "rbSBI";
            rbSBI.Size = new Size(241, 29);
            rbSBI.TabIndex = 0;
            rbSBI.TabStop = true;
            rbSBI.Text = "SBI e-Pay (5% discount)";
            rbSBI.UseVisualStyleBackColor = true;
            rbSBI.CheckedChanged += rbSBICheckedChanged;
            // 
            // txtAmount
            // 
            txtAmount.Font = new Font("Segoe UI", 11F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtAmount.Location = new Point(227, 29);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(252, 37);
            txtAmount.TabIndex = 12;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            label1.Location = new Point(33, 32);
            label1.Name = "label1";
            label1.Size = new Size(154, 30);
            label1.TabIndex = 11;
            label1.Text = "Enter amount";
            // 
            // lbls
            // 
            lbls.AutoSize = true;
            lbls.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            lbls.ForeColor = Color.Red;
            lbls.Location = new Point(227, 344);
            lbls.Name = "lbls";
            lbls.Size = new Size(0, 38);
            lbls.TabIndex = 19;
            // 
            // lblSelect
            // 
            lblSelect.AutoSize = true;
            lblSelect.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblSelect.ForeColor = Color.Red;
            lblSelect.Location = new Point(227, 351);
            lblSelect.Name = "lblSelect";
            lblSelect.Size = new Size(0, 30);
            lblSelect.TabIndex = 18;
            // 
            // cmbDebit
            // 
            cmbDebit.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            cmbDebit.FormattingEnabled = true;
            cmbDebit.Items.AddRange(new object[] { "Axis (15% Discount)", "ICICI (15% Discount)", "IDBI (15% Discount)", "Yes (11% Discount)", "SBI (11% Discount)", "BOB (11% Discount)", "Other Bank (5% Discount)" });
            cmbDebit.Location = new Point(227, 400);
            cmbDebit.Name = "cmbDebit";
            cmbDebit.Size = new Size(252, 33);
            cmbDebit.TabIndex = 17;
            cmbDebit.Text = "Select Debit Card";
            cmbDebit.Visible = false;
            // 
            // cmbCredit
            // 
            cmbCredit.FormattingEnabled = true;
            cmbCredit.Items.AddRange(new object[] { "Axis (20% Discount)", "ICICI (20% Discount)", "IDBI (20% Discount)", "Yes (15% Discount)", "SBI (15% Discount)", "BOB (15% Discount)", "Other Bank (8% Discount)" });
            cmbCredit.Location = new Point(227, 401);
            cmbCredit.Name = "cmbCredit";
            cmbCredit.Size = new Size(252, 33);
            cmbCredit.TabIndex = 16;
            cmbCredit.Text = "Select Credit Card";
            cmbCredit.Visible = false;
            // 
            // lblSelection
            // 
            lblSelection.AutoSize = true;
            lblSelection.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            lblSelection.Location = new Point(33, 400);
            lblSelection.Name = "lblSelection";
            lblSelection.Size = new Size(87, 30);
            lblSelection.TabIndex = 15;
            lblSelection.Text = "Select :";
            lblSelection.Visible = false;
            // 
            // txtAns
            // 
            txtAns.Font = new Font("Segoe UI Black", 14F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtAns.Location = new Point(227, 561);
            txtAns.Name = "txtAns";
            txtAns.Size = new Size(252, 45);
            txtAns.TabIndex = 21;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 11F, FontStyle.Bold);
            label3.Location = new Point(33, 571);
            label3.Name = "label3";
            label3.Size = new Size(180, 30);
            label3.TabIndex = 20;
            label3.Text = "Payable amount";
            // 
            // btnCalculate
            // 
            btnCalculate.BackColor = Color.FromArgb(191, 98, 243);
            btnCalculate.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnCalculate.Location = new Point(33, 466);
            btnCalculate.Name = "btnCalculate";
            btnCalculate.Size = new Size(209, 73);
            btnCalculate.TabIndex = 22;
            btnCalculate.Text = "Calculate";
            btnCalculate.UseVisualStyleBackColor = false;
            btnCalculate.Click += btnCalculateClick;
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(254, 100, 103);
            button1.Font = new Font("Segoe UI Black", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            button1.Location = new Point(270, 466);
            button1.Name = "button1";
            button1.Size = new Size(209, 73);
            button1.TabIndex = 25;
            button1.Text = "Reset";
            button1.UseVisualStyleBackColor = false;
            button1.Click += btnResetClick;
            // 
            // panel
            // 
            panel.BackColor = Color.FromArgb(29, 22, 22);
            panel.Controls.Add(pictureBox1);
            panel.Location = new Point(527, 0);
            panel.Name = "panel";
            panel.Size = new Size(656, 629);
            panel.TabIndex = 26;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(13, 17);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(600, 600);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 27;
            pictureBox1.TabStop = false;
            // 
            // P03
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(238, 238, 238);
            ClientSize = new Size(1152, 629);
            Controls.Add(panel);
            Controls.Add(button1);
            Controls.Add(btnCalculate);
            Controls.Add(txtAns);
            Controls.Add(label3);
            Controls.Add(lbls);
            Controls.Add(lblSelect);
            Controls.Add(cmbDebit);
            Controls.Add(cmbCredit);
            Controls.Add(lblSelection);
            Controls.Add(lblAmount);
            Controls.Add(groupBox1);
            Controls.Add(txtAmount);
            Controls.Add(label1);
            FormBorderStyle = FormBorderStyle.None;
            Name = "P03";
            Text = "Form1";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            panel.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label lblAmount;
        private GroupBox groupBox1;
        private RadioButton rbCOD;
        private RadioButton rbNet;
        private RadioButton rbDebit;
        private RadioButton rbCredit;
        private RadioButton rbSBI;
        private TextBox txtAmount;
        private Label label1;
        private Label lbls;
        private Label lblSelect;
        private ComboBox cmbDebit;
        private ComboBox cmbCredit;
        private Label lblSelection;
        private TextBox txtAns;
        private Label label3;
        private Button btnCalculate;
        private Button button1;
        private Panel panel;
        private PictureBox pictureBox1;
    }
}
