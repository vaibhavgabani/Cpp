using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Q05 : Form
    {
        char user = 'O';
        int counter = 0;
        public Q05()
        {
            InitializeComponent();
            labelUserName.Text = user.ToString();
            panel1.BackColor = Color.FromArgb(244, 248, 211);
        }

        private void buttonClick(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            btn.Enabled = false;
            btn.Text = user.ToString();
            counter++;

            // Switch user before checking the winner
            char currentUser = user;
            user = (user == 'O') ? 'X' : 'O';

            if (checkWinner())
            {
                MessageBox.Show(($"{currentUser} is the winner."));
                restart();
                return;
            }
            else if (counter == 9)
            {
                MessageBox.Show("Draw!!!");
                restart();
                return;
            }

            labelUserName.Text = user.ToString(); 
            panel1.BackColor = (user == 'X') ? Color.FromArgb(255, 160, 155) : Color.FromArgb(155, 199, 199);
        }


        private bool checkWinner()
        {
            if ((button1.Text != "" && button1.Text == button4.Text && button4.Text == button7.Text) || // column check
                (button2.Text != "" && button2.Text == button5.Text && button5.Text == button8.Text) ||
                (button3.Text != "" && button3.Text == button6.Text && button6.Text == button9.Text) ||
                (button1.Text != "" && button1.Text == button2.Text && button2.Text == button3.Text) || // row check
                (button4.Text != "" && button4.Text == button5.Text && button5.Text == button6.Text) ||
                (button7.Text != "" && button7.Text == button8.Text && button8.Text == button9.Text) ||
                (button1.Text != "" && button1.Text == button5.Text && button5.Text == button9.Text) ||  // diagonal check
                (button3.Text != "" && button3.Text == button5.Text && button5.Text == button7.Text))
            {
                return true;
            }
            return false;
        }

        private void restartBtn(object sender, EventArgs e)
        {
            restart();
        }

        private void restart()
        {
            foreach (Button btn in new[] { button1, button2, button3, button4, button5, button6, button7, button8, button9 })
            {
                btn.Text = string.Empty;
                btn.Enabled = true;
            }

            user = 'O';
            counter = 0;
            panel1.BackColor = Color.FromArgb(244, 248, 211);
        }
    }
}
