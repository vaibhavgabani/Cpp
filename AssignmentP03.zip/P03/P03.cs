namespace P03
{
    public partial class P03 : Form
    {
        public P03()
        {
            InitializeComponent();
            panel.SendToBack();
        }

        private void rbCreditCheckedChanged(object sender, EventArgs e)
        {
            cmbCredit.Visible = true;
            lblSelection.Visible = true;
            cmbDebit.Visible = false;
            cmbCredit.SelectedIndex = -1;
            cmbCredit.Text = "Select Credit Card";

        }

        private void rbDebitCheckedChanged(object sender, EventArgs e)
        {
            cmbDebit.Visible = true;
            lblSelection.Visible = true;
            cmbCredit.Visible = false;
            cmbDebit.SelectedIndex = -1;
            cmbDebit.Text = "Select Debit Card";
        }

        private void btnCalculateClick(object sender, EventArgs e)
        {
            if (txtAmount.TextLength == 0)
            {
                lblAmount.Text = "Enter amount !";
                return;
            }
            else if (!int.TryParse(txtAmount.Text, out int amount))
            {
                lblAmount.Text = "Enter valid amount !!";
                return;
            }
            lblAmount.Text = "";

            if (rbSBI.Checked || rbNet.Checked)
            {
                txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 5 / 100), 2).ToString();
            }
            else if (rbCOD.Checked)
            {
                txtAns.Text = txtAmount.Text;
            }
            else if (rbDebit.Checked)
            {
                if (cmbDebit.SelectedIndex == -1)
                {
                    lblSelect.Text = "Select Debit Card !!";
                    return;
                }
                lblSelect.Text = "";
                if (cmbDebit.SelectedIndex >= 0 && cmbDebit.SelectedIndex <= 2)
                {
                    txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 15 / 100), 2).ToString();
                }
                else if (cmbDebit.SelectedIndex >= 3 && cmbDebit.SelectedIndex <= 5)
                {
                    txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 11 / 100), 2).ToString();
                }
                else if (cmbDebit.SelectedIndex == 6)
                {
                    txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 5 / 100), 2).ToString();
                }
                cmbDebit.Visible = false;
                lblSelection.Visible = false;
            }
            else if (rbCredit.Checked)
            {
                if (cmbCredit.SelectedIndex == -1)
                {
                    lblSelect.Text = "Select Credit Card !!";
                    return;
                }
                lblSelect.Text = "";
                if (cmbCredit.SelectedIndex >= 0 && cmbCredit.SelectedIndex <= 2)
                {
                    txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 20 / 100), 2).ToString();
                }
                else if (cmbCredit.SelectedIndex >= 3 && cmbCredit.SelectedIndex <= 5)
                {
                    txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 15 / 100), 2).ToString();
                }
                else if (cmbCredit.SelectedIndex == 6)
                {
                    txtAns.Text = Math.Round(Convert.ToDouble(txtAmount.Text) - (Convert.ToDouble(txtAmount.Text) * 8 / 100), 2).ToString();
                }
                cmbCredit.Visible = false;
                lblSelection.Visible = false;
            }
            else
            {
                lbls.Text = "Select payment Method !!";
                return;
            }
            lbls.Text = "";
        }

        private void rbSBICheckedChanged(object sender, EventArgs e)
        {
            lblSelection.Visible = false;
            cmbDebit.Visible = false;
            cmbCredit.Visible = false;
        }

        private void rbNetCheckedChanged(object sender, EventArgs e)
        {
            lblSelection.Visible = false;
            cmbDebit.Visible = false;
            cmbCredit.Visible = false;
        }

        private void rbCODCheckedChanged(object sender, EventArgs e)
        {
            lblSelection.Visible = false;
            cmbDebit.Visible = false;
            cmbCredit.Visible = false;
        }

        private void btnResetClick(object sender, EventArgs e)
        {
            // Reset all text fields
            txtAmount.Text = string.Empty;
            txtAns.Text = string.Empty;

            // Reset all labels
            lblAmount.Text = string.Empty;
            lblSelect.Text = string.Empty;
            lbls.Text = string.Empty;

            // Reset all radio buttons
            rbSBI.Checked = false;
            rbNet.Checked = false;
            rbCOD.Checked = false;
            rbDebit.Checked = false;
            rbCredit.Checked = false;

            // Reset all combo boxes
            cmbDebit.SelectedIndex = -1;
            cmbCredit.SelectedIndex = -1;
            cmbDebit.Text = "Select Debit Card";
            cmbCredit.Text = "Select Credit Card";

            // Hide combo boxes and selection label
            cmbDebit.Visible = false;
            cmbCredit.Visible = false;
            lblSelection.Visible = false;
        }

    }
}
