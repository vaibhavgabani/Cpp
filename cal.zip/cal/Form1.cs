using System.Diagnostics;

namespace cal
{
    public partial class Form1 : Form
    {
        private string textValue = "";
        private string textArith = "";
        private double result = 0;
        private bool isOperationPerformed = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void inputNnumbers(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (isOperationPerformed)
            {
                textValue = "";
                isOperationPerformed = false;
            }
            textValue += button.Text;
            richTextBox1.Text = textValue;
        }

        private void Clear(object sender, EventArgs e)
        {
            textValue = "";
            textArith = "";
            result = 0;
            isOperationPerformed = false;
            richTextBox1.Text = "";
        }

        private void arithMetic(object sender, EventArgs e)
        {
            Button button = sender as Button;
            if (!string.IsNullOrEmpty(textValue))
            {
                if (result != 0)
                {
                    buttonSum(sender, e);
                }
                else
                {
                    result = Convert.ToDouble(textValue);
                }
            }
            textArith = button.Text;
            richTextBox1.Text = textArith; // Display the last performed arithmetic operation
            isOperationPerformed = true;
        }

        private void buttonSum(object sender, EventArgs e)
        {
            switch (textArith)
            {
                case "+":
                    result += Convert.ToDouble(textValue);
                    break;
                case "-":
                    result -= Convert.ToDouble(textValue);
                    break;
                case "*":
                    result *= Convert.ToDouble(textValue);
                    break;
                case "/":
                    result /= Convert.ToDouble(textValue);
                    break;
            }
            textValue = result.ToString();
            richTextBox1.Text = textValue;
            isOperationPerformed = true;
        }

        private void buttonCE(object sender, EventArgs e)
        {
            textValue = "";
            richTextBox1.Text = "0"; // Optionally, you can display 0 or clear the display
        }
    }
}